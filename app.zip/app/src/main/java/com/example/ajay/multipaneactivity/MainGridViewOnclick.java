package com.example.ajay.multipaneactivity;

/**
 * Created by ajay on 4/22/2016.
 */
public interface MainGridViewOnclick {
    public void Onclick(int pos, MovieDetails movieDetails);

}
