package com.example.ajay.multipaneactivity;

/**
 * Created by allu on 6/4/16.
 */
public interface TrailerListInterface {
    public void Onclick(int position,String id);
}
