package com.example.ajay.multipaneactivity;

import java.util.ArrayList;

/**
 * Created by ajay on 5/11/2016.
 */
public interface Communicator {
    public void Message(MovieDetails movieDetails);
}
